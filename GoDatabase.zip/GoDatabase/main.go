package main

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
)

func main() {
	fmt.Println("go connect to mysql")
	db, err := sql.Open("mysql", "root:Pragati@123@tcp/myphp")

	if err != nil {
		panic(err.Error())
	}

	if db != nil {
		fmt.Println("Connected to db...")
	}
	fmt.Println("connected")
	//defer db.close()
}
